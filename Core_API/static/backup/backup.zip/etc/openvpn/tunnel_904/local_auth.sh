#!/bin/sh
userpass=`cat $1`
username=`echo $userpass | awk '{print $1}'`
password=`echo $userpass | awk '{print $2}'`
python /etc/openvpn/tunnel_904/LocalAuth.py $username $password 904